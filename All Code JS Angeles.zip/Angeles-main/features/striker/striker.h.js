// striket.h.js

class Striker 
{
    init = null; // args: 1 - localPlayer
    process = null; // args: 1 - localPlayer
}
