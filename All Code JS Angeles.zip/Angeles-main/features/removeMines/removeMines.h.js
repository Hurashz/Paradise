// removeMines.h.js

class RemoveMines
{
    process = null; // args: 1 - localPlayer
}
